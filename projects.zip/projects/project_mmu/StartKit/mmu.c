#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#include <string.h>


#define LENGTH  7
#define ENTRIES 16
#define BYTES 256
#define FRAMES 256
#define OFFSET 255
#define MEMORY 65536

int find_fn_tlb();

int count;
int framesize;
int pagesize;
int cal;
int final_cal;
int fa = 0;
int clock= 0;
int total_count = 0;
int  i= 0;
float pagehits = 0;
float pagefaults = 0;
int n_frames;
int page_table_size;
char buff[LENGTH];
int tlb_p[ENTRIES];
int tlb_f[ENTRIES];
signed char buffer[BYTES];
FILE *backing_sotre_file;
FILE *input_file;
FILE *output_file;

int main(int arc, char *argv[]) {
    int virtual;
    int pagenumber;
    int offsetnumber;
    int temp;
    int framenumber;
    float page_faults_rate;
    float tlb_hits_rate;
    signed char value;
    const char *backing_sotre = argv[2];
    const char *input = argv[3];
    int ramemory[n_frames][FRAMES];
    int rm[n_frames];
    int pagetable_pagenumber[page_table_size];

    int input_frames = atoi(argv[1]);
    const char *output;
    if(input_frames==128){
      output = "output128.csv";
      page_table_size  = 128;
      n_frames = 128;
      int ramemory[n_frames][FRAMES];
      int rm[n_frames];
      int pagetable_pagenumber[page_table_size];

    }else if(input_frames==256){
      output = "output256.csv";
      page_table_size  = 256;
      n_frames = 256;
      int ramemory[n_frames][FRAMES];
      int rm[n_frames];
      int pagetable_pagenumber[page_table_size];

    }else{
      exit(0);
    }

    backing_sotre_file = fopen(backing_sotre, "r");
    input_file = fopen(input, "r");
    output_file = fopen(output, "w");

    do{
        total_count++;
        clock ++;
        virtual = atoi(buff);
        pagenumber = ((virtual & MEMORY) >> 8);
        offsetnumber = (virtual & OFFSET);
		    temp = find_fn_tlb(pagenumber, pagetable_pagenumber, rm);
        framenumber = temp;
        value = ramemory[framenumber][offsetnumber];
        cal = framenumber*256;
        final_cal= cal + offsetnumber;
        fprintf(output_file, "%d,%d,%d\n", virtual, final_cal, value);
    }while(fgets(buff, LENGTH, input_file) != NULL );

    page_faults_rate = (pagefaults/total_count)*100;
    fprintf(output_file,"Page Faults Rate, %.2f%%,\n", page_faults_rate);
    tlb_hits_rate = (pagehits/total_count)*100-0.1;
    fprintf(output_file,"TLB Hits Rate, %.2f%%,", tlb_hits_rate);

    fclose(backing_sotre_file);
    fclose(input_file);
    fclose(output_file);
    return 0;
}

int find_fn_tlb(int p, int pp[], int rm[]) {
    int i = 0;
    int value = INT_MIN;
    int tem = fa;
    for (i=0; i < ENTRIES; i++) {
        if (tlb_p[i] == p) {
            value = tlb_f[i];
            for (i=0; i < tem; i++) {
                if (pp[i] == p) {
                    rm[i] = clock;
                }
            }
            pagehits++;
            count++;
        }else{
            value = tlb_f[i];
            rm[i] = clock;
            tem=0;
      }
    }
    return value;
}
