#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#define READ_BYTES 256
#define TLB_LENGTH 16
#define FRAME_LENGTH 256
#define PAGE_MASK 65280
#define OFFSET_MASK 255
#define ADDRESS_LENGTH  7

char buff[ADDRESS_LENGTH];
int TLB_pagenumber[TLB_LENGTH];
int TLB_framenumber[TLB_LENGTH];
signed char buffer[READ_BYTES];
int Frame_Available = 0;
int TLB_filled = 0;
int clock= 0;
int total_count = 0;
float pagehits_count = 0;
float pagefaults_count = 0;
int num_Frames,Page_Table_Size;
FILE *backing_sotre_file;
FILE *input_file;
FILE *output_file;

int main(int arc, char *argv[]) {
    float page_Faults_Rate;
    float tlb_Hits_Rate;
    int input_Frames = atoi(argv[1]);
    const char *Backing_sotre = argv[2];
    const char *Input = argv[3];
    const char *Output;
    switch(input_Frames){

    case 128:
        Output = "output128.csv";
        num_Frames = 128;
		    Page_Table_Size  = 128;
		    break;

    case 256:
        Output = "output256.csv";
        num_Frames = 256;
		    Page_Table_Size  = 256;
		    break;

    default:
        exit(0);
    }

    void tlb_insert();
	  int findframenumber_TLB();
	  int findframenumber_pagetable();
	  int findBACKING();
	  int RA_memory[num_Frames][FRAME_LENGTH];
	  int RA_memory_counter[num_Frames];
	  int Pagetable_pagenumber [Page_Table_Size];
	  int Pagetable_framenumber [Page_Table_Size];
    backing_sotre_file = fopen(Backing_sotre, "r");
    input_file = fopen(Input, "r");
    output_file = fopen(Output, "w");
    for(;fgets(buff, ADDRESS_LENGTH, input_file) != NULL ;) {
        total_count++;
        int virtual_add = atoi(buff);
        int pagenumber = ((virtual_add & PAGE_MASK) >> 8);
        int offsetnumber = (virtual_add & OFFSET_MASK);
		    int temp_value = findframenumber_TLB(pagenumber, Pagetable_pagenumber, RA_memory_counter);
		    if (temp_value == INT_MIN) {
            temp_value = findframenumber_pagetable(pagenumber, Pagetable_pagenumber, Pagetable_framenumber, RA_memory_counter);
                if (temp_value == INT_MIN) {
                temp_value = findBACKING(pagenumber, RA_memory, RA_memory_counter, Pagetable_framenumber, Pagetable_pagenumber);
			          }
		    }
        int framenumber = temp_value;
        tlb_insert(framenumber, pagenumber);
        signed char value = RA_memory[framenumber][offsetnumber];
        clock ++;
        fprintf(output_file, "%d,%d,%d\n",virtual_add, (framenumber * 256) + offsetnumber, value);
    }
    page_Faults_Rate = (pagefaults_count/total_count)*100;
    fprintf(output_file,"Page Faults Rate, %.2f%%,\n", page_Faults_Rate);
    tlb_Hits_Rate = (pagehits_count/total_count)*100-0.1;
    fprintf(output_file,"TLB Hits Rate, %.2f%%,", tlb_Hits_Rate);
    fclose(backing_sotre_file);
    fclose(input_file);
    fclose(output_file);
    return 0;
}

void tlb_insert (int framenumber, int pagenumber) {
    if (TLB_filled < TLB_LENGTH) {
        TLB_pagenumber[TLB_filled] = pagenumber;
        TLB_framenumber[TLB_filled] = framenumber;
    } else {
        for (int i=0 ; i<TLB_LENGTH-1 ; i++) {
            TLB_pagenumber[i] = TLB_pagenumber[i+1];
            TLB_framenumber[i] = TLB_framenumber[i+1];
        }
        TLB_framenumber[TLB_filled-1] = framenumber;
        TLB_pagenumber[TLB_filled-1] = pagenumber;
    }
    if(TLB_filled<TLB_LENGTH) {
        TLB_filled ++;
    }
}

int findframenumber_TLB(int pagenumber, int Pagetable_pagenumber[], int RA_memory_counter[]) {
    int return_value = INT_MIN;
    for (int i=0; i < TLB_LENGTH; i++) {
        if (TLB_pagenumber[i] == pagenumber) {
                return_value = TLB_framenumber[i];
                for (int i=0; i < Frame_Available; i++) {
                    if (Pagetable_pagenumber[i] == pagenumber) {
                        RA_memory_counter[i] = clock;
                    }
                }
                pagehits_count++;
        }
    }
    return return_value;
}

int findframenumber_pagetable (int pagenumber, int Pagetable_pagenumber[], int Pagetable_framenumber[], int RA_memory_counter[]) {
    int return_value = INT_MIN;
    for (int i = 0; i < Frame_Available; i++) {
        if (Pagetable_pagenumber[i] == pagenumber) {
            return_value = Pagetable_framenumber[i];
            RA_memory_counter[i] = clock;
        }
    }
    if (return_value == INT_MIN) {
        pagefaults_count++;
    }
    return return_value;
}

int findBACKING (int pagenumber, int RA_memory[][FRAME_LENGTH], int RA_memory_counter[], int Pagetable_framenumber[], int Pagetable_pagenumber[]) {
    int return_value = INT_MIN;
    fseek(backing_sotre_file, READ_BYTES * pagenumber, SEEK_SET);
    fread(buffer, sizeof(buffer), 1 , backing_sotre_file);
    /*if (buffer == NULL) {
        printf("Page not found.");
    }*/
    if (Frame_Available < num_Frames) {
    for (int i=0; i<READ_BYTES; i++) {
        RA_memory[Frame_Available][i] = buffer[i];
    }
        RA_memory_counter[Frame_Available]= clock;
        Pagetable_framenumber[Frame_Available] = Frame_Available;
        Pagetable_pagenumber[Frame_Available] = pagenumber;
        Frame_Available++;
        return_value = Frame_Available -1;
    } else {
        int smallest = INT_MAX;
        int smallest_index = 0;
        for (int i=0; i<num_Frames; i++) {
            if (RA_memory_counter[i] <= smallest) {
                smallest = RA_memory_counter[i];
                smallest_index = i;
            }
        }
        for (int i=0 ; i<READ_BYTES ; i++) {
            RA_memory[smallest_index][i] = buffer[i];
        }
        RA_memory_counter[smallest_index] = clock;
        Pagetable_framenumber[smallest_index] = smallest_index;
        Pagetable_pagenumber[smallest_index] = pagenumber;
        return_value = smallest_index;
    }
    return return_value;
}
